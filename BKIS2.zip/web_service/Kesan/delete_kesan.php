<?php 
	$id = $_GET['id'];
	
	require_once('../koneksi.php');
	
	$sql = "DELETE FROM cliente WHERE id=$id;";
	
	if(mysqli_query($con,$sql)){
		echo 'Eliminacion de Cliente Concluida';
	}else{
		echo 'Error! Porfavor Intente de Nuevo!';
	}
	
	mysqli_close($con);