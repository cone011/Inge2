<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){

		$id = $_POST['id'];
		$fullname = $_POST['fullname'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$kesan = $_POST['kesan'];
		
		require_once('../koneksi.php');

		$sql = "UPDATE cliente SET fullname = '$fullname', gender = '$gender', address = '$address', obs = '$kesan' WHERE id = $id;";
		
		if(mysqli_query($con,$sql)) {
				echo "Actualizacion Concluida";
				} else {
				echo 'Fallo de Actualizacion!';
				}
		
		mysqli_close($con);
	}