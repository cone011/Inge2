<?php
if($_SERVER['REQUEST_METHOD']=='POST'){

		$nama_makanan = $_POST['nama_makanan'];
		$asal_makanan = $_POST['asal_makanan'];
		$harga_makanan = $_POST['harga_makanan'];
		

				$sql = "INSERT INTO proyecto (nombre,equipo,obs) VALUES ('$nama_makanan','$asal_makanan','$harga_makanan')";

				require_once('../koneksi.php');

				if(mysqli_query($con,$sql)) {
				echo 'Proyecto Add Exitosamente!';
				} else {
				echo 'Fallo el Add Proyecto!';
				}

		mysqli_close($con);
	}
