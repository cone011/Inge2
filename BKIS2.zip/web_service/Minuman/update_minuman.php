<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){

		$no = $_POST['no'];
		$nama_minuman = $_POST['nama_minuman'];
		$perusahaan = $_POST['perusahaan'];
		$netto = $_POST['netto'];
		$sedotan = $_POST['sedotan'];
		$tempat = $_POST['tempat'];
		$nama_pemesan = $_POST['nama_pemesan'];
		
		require_once('../koneksi.php');

		$sql = "UPDATE userstory SET nombre = '$nama_minuman', email = '$perusahaan', fecha = '$netto', rol = '$sedotan', estado = '$tempat', obs = '$nama_pemesan' WHERE no = $no;";
		
		if(mysqli_query($con,$sql)) {
				echo "UserStory Actualizado Correctamente";
				} else {
				echo 'Error Intentelo de Nuevo!';
				}
		
		mysqli_close($con);
	}
