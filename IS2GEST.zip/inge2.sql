-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2018 at 03:43 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inge2`
--

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(25) NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `address` varchar(30) NOT NULL,
  `obs` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`id`, `fullname`, `gender`, `address`, `obs`) VALUES
(1, 'jwjsjdj', 'Laki-Laki', 'jdjdjdj', 'jfjfjf'),
(2, 'jdjdjd', 'Perempuan', 'jsjsjsjs', 'jsjdjddjjdjf'),
(3, 'ejejejeej', 'Perempuan', 'jsjsdjdjd', 'jfkfkfkfgk'),
(4, 'aaaa', 'Perempuan', 'aaas', 'aaa'),
(5, 'rwdt', 'Laki-Laki', 'jsjsjsbbs', 'jjsjsjsdbdj'),
(6, 'hajsj', 'Perempuan', 'jsjsns', 'bssjsjsk'),
(7, 'hjsj', '', 'bsbbsjjjdd', 'zjsjdjd\njddjdjd'),
(8, 'hshjd', '', 'ndnbddn', 'nznzzn'),
(9, 'jwwjwj', '', 'nssjjsjd', 'jssjjsjj'),
(10, 'jddjdn', '', 'dndndndn', 'dndndd'),
(11, 'ejejdj', '', 'jsjsbsb', 'jsjsjsjs'),
(12, 'wee1', '', 'we1', 'we'),
(13, 'jwjjs', '', 'bsbssbsn', 'rdt'),
(14, 'er2', '', 'er2', 'er2');

-- --------------------------------------------------------

--
-- Table structure for table `proyecto`
--

CREATE TABLE IF NOT EXISTS `proyecto` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `equipo` varchar(30) NOT NULL,
  `obs` varchar(30) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `proyecto`
--

INSERT INTO `proyecto` (`no`, `nombre`, `equipo`, `obs`) VALUES
(1, '', '', ''),
(2, 'test', 'test', '09/08/2017'),
(3, 'sssjj', 'nsnsnndndn', 'ndddndnndfdjfjfj'),
(4, 'test1', 'test1', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(50) NOT NULL,
  `email` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `gender` enum('Laki-Laki','Perempuan') NOT NULL,
  `address` varchar(100) NOT NULL,
  `telp` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `username`, `password`, `gender`, `address`, `telp`) VALUES
(4, 'test', 'test@gmail.com', 'test', 'test', 'Perempuan', 'asdasdasdas', ''),
(5, 'br', 'br@gmail.com', 'br', 'br', 'Perempuan', 'bsjsbbsb', '125'),
(6, 'py', 'py@gmail.com', 'py', 'py', '', 'sshshj', '0971240458'),
(8, 'uu', 'uu@hotmail.com', 'uu', 'uu', '', 'yy', '5236684'),
(10, 'hqjaj', 'op', 'op', 'op', '', 'ope', '0971345869');

-- --------------------------------------------------------

--
-- Table structure for table `userstory`
--

CREATE TABLE IF NOT EXISTS `userstory` (
  `no` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `fecha` varchar(10) NOT NULL,
  `rol` varchar(10) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `obs` varchar(30) NOT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `userstory`
--

INSERT INTO `userstory` (`no`, `nombre`, `email`, `fecha`, `rol`, `estado`, `obs`) VALUES
(1, 'jsjej', 'sjdndnb', '09/09/2017', 'Yes', 'Cup', 'hshsbsjsd'),
(2, 'wjejejj', 'ndbdbfbb', 'ndbdndb', 'No', 'Cup', 'jwwjjs'),
(3, 'aahsh', 'sbsbsb', 'jsdbsb', 'No', 'Cup', ''),
(4, 'aahsh', 'sbsbsb', 'jsdbsb', 'No', 'Cup', 'eddf'),
(5, 'test', 'test', '2i384ir', 'No', 'Cup', 'jwjwjwwjjw'),
(6, 'hssjh', 'sjssjsb', 'Nzznzndnn', 'No', 'Cup', 'sjsjsjjs'),
(7, 'shsjsj', 'dkejendn', 'bdndjdjd', 'Administra', 'En Proceso', 'jddjjjfjj'),
(8, 'sbbsnsn', 'dndnnn', 'snsbsbsnsn', 'Administra', 'En Proceso', 'dbdbdndndbd'),
(9, 'op', 'opsdnd', 'opdnd', 'Usuario', 'En Proceso', 'jsjdjd'),
(10, 'ert', 'ert', '90131', 'Usuario', 'En Proceso', 'ert');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
