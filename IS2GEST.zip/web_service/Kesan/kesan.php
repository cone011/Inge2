<?php
if($_SERVER['REQUEST_METHOD']=='POST'){

		$fullname = $_POST['fullname'];
		$gender = $_POST['gender'];
		$address = $_POST['address'];
		$kesan = $_POST['kesan'];

				$sql = "INSERT INTO cliente (fullname,gender,address,obs) VALUES ('$fullname','$gender','$address','$kesan')";

				require_once('../koneksi.php');

				if(mysqli_query($con,$sql)) {
				echo 'Add Cliente Exitosamente';
				} else {
				echo 'Fallo el add Cliente!';
				}

		mysqli_close($con);
	}