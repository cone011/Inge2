<?php 
	$no = $_GET['no'];
	
	require_once('../koneksi.php');
	
	$sql = "DELETE FROM proyecto WHERE no=$no;";
	
	if(mysqli_query($con,$sql)){
		echo 'Proyecto Eliminado';
	}else{
		echo 'Error!';
	}
	
	mysqli_close($con);
