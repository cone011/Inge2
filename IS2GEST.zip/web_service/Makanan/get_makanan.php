<?php 
	$no = $_GET['no'];
	
	require_once('../koneksi.php');
	
	$sql = "SELECT * FROM proyecto WHERE no=$no";
	
	$r = mysqli_query($con,$sql);
	
	$result = array();

	$row = mysqli_fetch_array($r);
	
	array_push($result,array("no"=>$row['no'], 
							"nama_makanan"=>$row['nombre'], 
							"asal_makanan"=>$row['equipo'], 
							"harga_makanan"=>$row['obs']));

	echo json_encode(array('result'=>$result));
	
	mysqli_close($con);
