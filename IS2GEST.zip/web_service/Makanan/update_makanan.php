<?php 
	if($_SERVER['REQUEST_METHOD']=='POST'){

		$no = $_POST['no'];
		$nama_makanan = $_POST['nama_makanan'];
		$asal_makanan = $_POST['asal_makanan'];
		$harga_makanan = $_POST['harga_makanan'];
		
		require_once('../koneksi.php');

		$sql = "UPDATE proyecto SET nombre = '$nama_makanan', equipo = '$asal_makanan', obs = '$harga_makanan' WHERE no = $no;";
		
		if(mysqli_query($con,$sql)) {
				echo "Proyecto Actualizado";
				} else {
				echo 'Fallo Actualizacion!';
				}
		
		mysqli_close($con);
	}
