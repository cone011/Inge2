<?php 
	$no = $_GET['no'];
	
	require_once('../koneksi.php');
	
	$sql = "DELETE FROM userstory WHERE no=$no;";
	
	if(mysqli_query($con,$sql)){
		echo 'UserStory Eliminado Correctamente';
	}else{
		echo 'Error!';
	}
	
	mysqli_close($con);
