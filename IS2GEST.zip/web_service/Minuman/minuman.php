<?php
if($_SERVER['REQUEST_METHOD']=='POST'){

		$nama_minuman = $_POST['nama_minuman'];
		$perusahaan = $_POST['perusahaan'];
		$netto = $_POST['netto'];
		$sedotan = $_POST['sedotan'];
		$tempat = $_POST['tempat'];
		$nama_pemesan = $_POST['nama_pemesan'];
		

				$sql = "INSERT INTO userstory (nombre,email,fecha,rol,estado,obs) VALUES ('$nama_minuman','$perusahaan','$netto','$sedotan','$tempat','$nama_pemesan')";

				require_once('../koneksi.php');

				if(mysqli_query($con,$sql)) {
				echo 'UserStory Add Correctamente!';
				} else {
				echo 'UserStory no Add!';
				}

		mysqli_close($con);
	}
