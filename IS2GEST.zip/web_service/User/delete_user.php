<?php 
	$id = $_GET['id'];
	
	require_once('../koneksi.php');
	
	$sql = "DELETE FROM users WHERE id=$id;";
	
	if(mysqli_query($con,$sql)){
		echo 'Datos de usuario borrados con éxito';
	}else{
		echo 'Error! Por favor intente de nuevo!';
	}
	
	mysqli_close($con);