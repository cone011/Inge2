/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "fase")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Fase.findAll", query = "SELECT f FROM Fase f")
    , @NamedQuery(name = "Fase.findByCodigoFase", query = "SELECT f FROM Fase f WHERE f.codigoFase = :codigoFase")
    , @NamedQuery(name = "Fase.findByDescripcion", query = "SELECT f FROM Fase f WHERE f.descripcion = :descripcion")})
public class Fase implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigo_fase")
    private BigDecimal codigoFase;
    @Size(max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @OneToMany(mappedBy = "codigoFase")
    private Collection<Flujo> flujoCollection;

    public Fase() {
    }

    public Fase(BigDecimal codigoFase) {
        this.codigoFase = codigoFase;
    }

    public BigDecimal getCodigoFase() {
        return codigoFase;
    }

    public void setCodigoFase(BigDecimal codigoFase) {
        this.codigoFase = codigoFase;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @XmlTransient
    public Collection<Flujo> getFlujoCollection() {
        return flujoCollection;
    }

    public void setFlujoCollection(Collection<Flujo> flujoCollection) {
        this.flujoCollection = flujoCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoFase != null ? codigoFase.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Fase)) {
            return false;
        }
        Fase other = (Fase) object;
        if ((this.codigoFase == null && other.codigoFase != null) || (this.codigoFase != null && !this.codigoFase.equals(other.codigoFase))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Fase[ codigoFase=" + codigoFase + " ]";
    }
    
}
