/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "flujo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Flujo.findAll", query = "SELECT f FROM Flujo f")
    , @NamedQuery(name = "Flujo.findByCodigoFlujo", query = "SELECT f FROM Flujo f WHERE f.codigoFlujo = :codigoFlujo")
    , @NamedQuery(name = "Flujo.findByDescripcion", query = "SELECT f FROM Flujo f WHERE f.descripcion = :descripcion")})
public class Flujo implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigo_flujo")
    private BigDecimal codigoFlujo;
    @Size(max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @JoinColumn(name = "estado_flujo", referencedColumnName = "codigo_estado")
    @ManyToOne
    private Estado estadoFlujo;
    @JoinColumn(name = "codigo_fase", referencedColumnName = "codigo_fase")
    @ManyToOne
    private Fase codigoFase;
    @OneToMany(mappedBy = "codigoFlujo")
    private Collection<Actividad> actividadCollection;

    public Flujo() {
    }

    public Flujo(BigDecimal codigoFlujo) {
        this.codigoFlujo = codigoFlujo;
    }

    public BigDecimal getCodigoFlujo() {
        return codigoFlujo;
    }

    public void setCodigoFlujo(BigDecimal codigoFlujo) {
        this.codigoFlujo = codigoFlujo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Estado getEstadoFlujo() {
        return estadoFlujo;
    }

    public void setEstadoFlujo(Estado estadoFlujo) {
        this.estadoFlujo = estadoFlujo;
    }

    public Fase getCodigoFase() {
        return codigoFase;
    }

    public void setCodigoFase(Fase codigoFase) {
        this.codigoFase = codigoFase;
    }

    @XmlTransient
    public Collection<Actividad> getActividadCollection() {
        return actividadCollection;
    }

    public void setActividadCollection(Collection<Actividad> actividadCollection) {
        this.actividadCollection = actividadCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoFlujo != null ? codigoFlujo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flujo)) {
            return false;
        }
        Flujo other = (Flujo) object;
        if ((this.codigoFlujo == null && other.codigoFlujo != null) || (this.codigoFlujo != null && !this.codigoFlujo.equals(other.codigoFlujo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Flujo[ codigoFlujo=" + codigoFlujo + " ]";
    }
    
}
