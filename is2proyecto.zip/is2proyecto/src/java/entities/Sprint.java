/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "sprint")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sprint.findAll", query = "SELECT s FROM Sprint s")
    , @NamedQuery(name = "Sprint.findByCodigoSprint", query = "SELECT s FROM Sprint s WHERE s.codigoSprint = :codigoSprint")
    , @NamedQuery(name = "Sprint.findByDescripcion", query = "SELECT s FROM Sprint s WHERE s.descripcion = :descripcion")
    , @NamedQuery(name = "Sprint.findByDuracion", query = "SELECT s FROM Sprint s WHERE s.duracion = :duracion")
    , @NamedQuery(name = "Sprint.findByEstado", query = "SELECT s FROM Sprint s WHERE s.estado = :estado")})
public class Sprint implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigo_sprint")
    private BigDecimal codigoSprint;
    @Size(max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @Column(name = "duracion")
    @Temporal(TemporalType.TIMESTAMP)
    private Date duracion;
    @Column(name = "estado")
    private Character estado;
    @JoinColumn(name = "codigo_proyecto", referencedColumnName = "codigo_proyecto")
    @ManyToOne
    private Proyecto codigoProyecto;
    @JoinColumn(name = "tipo_sprint", referencedColumnName = "cod_tipo_sprint")
    @ManyToOne
    private TipoSprint tipoSprint;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "sprint")
    private UserStory userStory;

    public Sprint() {
    }

    public Sprint(BigDecimal codigoSprint) {
        this.codigoSprint = codigoSprint;
    }

    public BigDecimal getCodigoSprint() {
        return codigoSprint;
    }

    public void setCodigoSprint(BigDecimal codigoSprint) {
        this.codigoSprint = codigoSprint;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getDuracion() {
        return duracion;
    }

    public void setDuracion(Date duracion) {
        this.duracion = duracion;
    }

    public Character getEstado() {
        return estado;
    }

    public void setEstado(Character estado) {
        this.estado = estado;
    }

    public Proyecto getCodigoProyecto() {
        return codigoProyecto;
    }

    public void setCodigoProyecto(Proyecto codigoProyecto) {
        this.codigoProyecto = codigoProyecto;
    }

    public TipoSprint getTipoSprint() {
        return tipoSprint;
    }

    public void setTipoSprint(TipoSprint tipoSprint) {
        this.tipoSprint = tipoSprint;
    }

    public UserStory getUserStory() {
        return userStory;
    }

    public void setUserStory(UserStory userStory) {
        this.userStory = userStory;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoSprint != null ? codigoSprint.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sprint)) {
            return false;
        }
        Sprint other = (Sprint) object;
        if ((this.codigoSprint == null && other.codigoSprint != null) || (this.codigoSprint != null && !this.codigoSprint.equals(other.codigoSprint))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Sprint[ codigoSprint=" + codigoSprint + " ]";
    }
    
}
