/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "tipoSprint")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TipoSprint.findAll", query = "SELECT t FROM TipoSprint t")
    , @NamedQuery(name = "TipoSprint.findByCodTipoSprint", query = "SELECT t FROM TipoSprint t WHERE t.codTipoSprint = :codTipoSprint")
    , @NamedQuery(name = "TipoSprint.findByDescripcion", query = "SELECT t FROM TipoSprint t WHERE t.descripcion = :descripcion")})
public class TipoSprint implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "cod_tipo_sprint")
    private BigDecimal codTipoSprint;
    @Size(max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @OneToMany(mappedBy = "tipoSprint")
    private Collection<Sprint> sprintCollection;

    public TipoSprint() {
    }

    public TipoSprint(BigDecimal codTipoSprint) {
        this.codTipoSprint = codTipoSprint;
    }

    public BigDecimal getCodTipoSprint() {
        return codTipoSprint;
    }

    public void setCodTipoSprint(BigDecimal codTipoSprint) {
        this.codTipoSprint = codTipoSprint;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @XmlTransient
    public Collection<Sprint> getSprintCollection() {
        return sprintCollection;
    }

    public void setSprintCollection(Collection<Sprint> sprintCollection) {
        this.sprintCollection = sprintCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codTipoSprint != null ? codTipoSprint.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TipoSprint)) {
            return false;
        }
        TipoSprint other = (TipoSprint) object;
        if ((this.codTipoSprint == null && other.codTipoSprint != null) || (this.codTipoSprint != null && !this.codTipoSprint.equals(other.codTipoSprint))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.TipoSprint[ codTipoSprint=" + codTipoSprint + " ]";
    }
    
}
