/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "tipoUS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TipoUS.findAll", query = "SELECT t FROM TipoUS t")
    , @NamedQuery(name = "TipoUS.findByIdTipoUs", query = "SELECT t FROM TipoUS t WHERE t.idTipoUs = :idTipoUs")
    , @NamedQuery(name = "TipoUS.findByNombre", query = "SELECT t FROM TipoUS t WHERE t.nombre = :nombre")
    , @NamedQuery(name = "TipoUS.findByDescripcion", query = "SELECT t FROM TipoUS t WHERE t.descripcion = :descripcion")
    , @NamedQuery(name = "TipoUS.findByObservacion", query = "SELECT t FROM TipoUS t WHERE t.observacion = :observacion")})
public class TipoUS implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_tipo_us")
    private BigDecimal idTipoUs;
    @Size(max = 2147483647)
    @Column(name = "nombre")
    private String nombre;
    @Size(max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @Size(max = 2147483647)
    @Column(name = "observacion")
    private String observacion;
    @OneToMany(mappedBy = "tipoUs")
    private Collection<UserStory> userStoryCollection;

    public TipoUS() {
    }

    public TipoUS(BigDecimal idTipoUs) {
        this.idTipoUs = idTipoUs;
    }

    public BigDecimal getIdTipoUs() {
        return idTipoUs;
    }

    public void setIdTipoUs(BigDecimal idTipoUs) {
        this.idTipoUs = idTipoUs;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    @XmlTransient
    public Collection<UserStory> getUserStoryCollection() {
        return userStoryCollection;
    }

    public void setUserStoryCollection(Collection<UserStory> userStoryCollection) {
        this.userStoryCollection = userStoryCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTipoUs != null ? idTipoUs.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TipoUS)) {
            return false;
        }
        TipoUS other = (TipoUS) object;
        if ((this.idTipoUs == null && other.idTipoUs != null) || (this.idTipoUs != null && !this.idTipoUs.equals(other.idTipoUs))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.TipoUS[ idTipoUs=" + idTipoUs + " ]";
    }
    
}
