/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author User
 */
@Entity
@Table(name = "userStory")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserStory.findAll", query = "SELECT u FROM UserStory u")
    , @NamedQuery(name = "UserStory.findByIdStory", query = "SELECT u FROM UserStory u WHERE u.idStory = :idStory")
    , @NamedQuery(name = "UserStory.findByFechaCreacion", query = "SELECT u FROM UserStory u WHERE u.fechaCreacion = :fechaCreacion")
    , @NamedQuery(name = "UserStory.findByHoraCreacion", query = "SELECT u FROM UserStory u WHERE u.horaCreacion = :horaCreacion")
    , @NamedQuery(name = "UserStory.findByNombreUsuario", query = "SELECT u FROM UserStory u WHERE u.nombreUsuario = :nombreUsuario")
    , @NamedQuery(name = "UserStory.findByApellidoUsuario", query = "SELECT u FROM UserStory u WHERE u.apellidoUsuario = :apellidoUsuario")
    , @NamedQuery(name = "UserStory.findByRol", query = "SELECT u FROM UserStory u WHERE u.rol = :rol")
    , @NamedQuery(name = "UserStory.findByEmail", query = "SELECT u FROM UserStory u WHERE u.email = :email")})
public class UserStory implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_story")
    private Integer idStory;
    @Column(name = "fecha_creacion")
    @Temporal(TemporalType.DATE)
    private Date fechaCreacion;
    @Column(name = "hora_creacion")
    @Temporal(TemporalType.TIME)
    private Date horaCreacion;
    @Size(max = 2147483647)
    @Column(name = "nombre_usuario")
    private String nombreUsuario;
    @Size(max = 2147483647)
    @Column(name = "apellido_usuario")
    private String apellidoUsuario;
    @Size(max = 2147483647)
    @Column(name = "rol")
    private String rol;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 2147483647)
    @Column(name = "email")
    private String email;
    @OneToMany(mappedBy = "idStory")
    private Collection<VersionUS> versionUSCollection;
    @JoinColumn(name = "id_story", referencedColumnName = "codigo_sprint", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Sprint sprint;
    @JoinColumn(name = "tipo_us", referencedColumnName = "id_tipo_us")
    @ManyToOne
    private TipoUS tipoUs;
    @JoinColumn(name = "id_story", referencedColumnName = "id_usuario", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Usuario usuario;

    public UserStory() {
    }

    public UserStory(Integer idStory) {
        this.idStory = idStory;
    }

    public Integer getIdStory() {
        return idStory;
    }

    public void setIdStory(Integer idStory) {
        this.idStory = idStory;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getHoraCreacion() {
        return horaCreacion;
    }

    public void setHoraCreacion(Date horaCreacion) {
        this.horaCreacion = horaCreacion;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @XmlTransient
    public Collection<VersionUS> getVersionUSCollection() {
        return versionUSCollection;
    }

    public void setVersionUSCollection(Collection<VersionUS> versionUSCollection) {
        this.versionUSCollection = versionUSCollection;
    }

    public Sprint getSprint() {
        return sprint;
    }

    public void setSprint(Sprint sprint) {
        this.sprint = sprint;
    }

    public TipoUS getTipoUs() {
        return tipoUs;
    }

    public void setTipoUs(TipoUS tipoUs) {
        this.tipoUs = tipoUs;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idStory != null ? idStory.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserStory)) {
            return false;
        }
        UserStory other = (UserStory) object;
        if ((this.idStory == null && other.idStory != null) || (this.idStory != null && !this.idStory.equals(other.idStory))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.UserStory[ idStory=" + idStory + " ]";
    }
    
}
