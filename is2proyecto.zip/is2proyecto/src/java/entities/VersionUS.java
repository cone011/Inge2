/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "versionUS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "VersionUS.findAll", query = "SELECT v FROM VersionUS v")
    , @NamedQuery(name = "VersionUS.findByIdVersion", query = "SELECT v FROM VersionUS v WHERE v.idVersion = :idVersion")
    , @NamedQuery(name = "VersionUS.findByFechaCreacion", query = "SELECT v FROM VersionUS v WHERE v.fechaCreacion = :fechaCreacion")
    , @NamedQuery(name = "VersionUS.findByHoraCreacion", query = "SELECT v FROM VersionUS v WHERE v.horaCreacion = :horaCreacion")
    , @NamedQuery(name = "VersionUS.findByNombreUsuario", query = "SELECT v FROM VersionUS v WHERE v.nombreUsuario = :nombreUsuario")
    , @NamedQuery(name = "VersionUS.findByApellidoUsuario", query = "SELECT v FROM VersionUS v WHERE v.apellidoUsuario = :apellidoUsuario")
    , @NamedQuery(name = "VersionUS.findByRol", query = "SELECT v FROM VersionUS v WHERE v.rol = :rol")
    , @NamedQuery(name = "VersionUS.findByEmail", query = "SELECT v FROM VersionUS v WHERE v.email = :email")})
public class VersionUS implements Serializable {

    private static final long serialVersionUID = 1L;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "id_version")
    private BigDecimal idVersion;
    @Column(name = "fecha_creacion")
    @Temporal(TemporalType.DATE)
    private Date fechaCreacion;
    @Column(name = "hora_creacion")
    @Temporal(TemporalType.TIME)
    private Date horaCreacion;
    @Size(max = 2147483647)
    @Column(name = "nombre_usuario")
    private String nombreUsuario;
    @Size(max = 2147483647)
    @Column(name = "apellido_usuario")
    private String apellidoUsuario;
    @Size(max = 2147483647)
    @Column(name = "rol")
    private String rol;
    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Size(max = 2147483647)
    @Column(name = "email")
    private String email;
    @JoinColumn(name = "id_story", referencedColumnName = "id_story")
    @ManyToOne
    private UserStory idStory;

    public VersionUS() {
    }

    public VersionUS(BigDecimal idVersion) {
        this.idVersion = idVersion;
    }

    public BigDecimal getIdVersion() {
        return idVersion;
    }

    public void setIdVersion(BigDecimal idVersion) {
        this.idVersion = idVersion;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getHoraCreacion() {
        return horaCreacion;
    }

    public void setHoraCreacion(Date horaCreacion) {
        this.horaCreacion = horaCreacion;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getApellidoUsuario() {
        return apellidoUsuario;
    }

    public void setApellidoUsuario(String apellidoUsuario) {
        this.apellidoUsuario = apellidoUsuario;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserStory getIdStory() {
        return idStory;
    }

    public void setIdStory(UserStory idStory) {
        this.idStory = idStory;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idVersion != null ? idVersion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof VersionUS)) {
            return false;
        }
        VersionUS other = (VersionUS) object;
        if ((this.idVersion == null && other.idVersion != null) || (this.idVersion != null && !this.idVersion.equals(other.idVersion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.VersionUS[ idVersion=" + idVersion + " ]";
    }
    
}
